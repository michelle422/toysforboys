package be.vdab.exceptions;

public class RecordAangepastException extends RuntimeException {
	public static final long serialVersionUID = 1L;
}
