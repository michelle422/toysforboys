package be.vdab.enums;

public enum Status {
	CANCELLED, DISPUTED, PROCESSING, RESOLVED, SHIPPED, WAITING
}
